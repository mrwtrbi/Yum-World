<footer>
<div class="footer-container">
	<div class="colonne">
	<h3>Plan du site</h3>
	<ul>
		<li><a href="#"><i class="fa-solid fa-earth-africa"></i> Afrique</a></li>
		<li><a href="#"><i class="fa-solid fa-earth-americas"></i> Amérique</a></li>
		<li><a href="#"><i class="fa-solid fa-earth-asia"></i> Asie</a></li>
		<li><a href="#"><i class="fa-solid fa-earth-europe"></i> Europe</a></li>
		<li><a href="#"><i class="fa-solid fa-earth-oceania"></i> Océanie</a></li>
	</ul>
	</div>

	<div class="colonne">
	<h3>Mentions légales</h3>
	<ul>
		<li><a href="#"><i class="fa-solid fa-lock"></i> Politique de confidentialité</a></li>
		<li><a href="#"><i class="fa-solid fa-house-circle-check"></i> Hébergeur du site</a></li>
		<li><a href="conceptrices.php"><i class="fa-solid fa-lightbulb"></i> Conceptrices du site</a></li>
	</ul>
	</div>

	<div class="colonne">
	<h3>Nous contacter</h3>
	<ul>
		<li><a href="conceptrices.php"><i class="fa-solid fa-lightbulb"></i> Conceptrices</a></li>
		<li><a href="#"><i class="fa-solid fa-briefcase"></i> Société</a></li>
		<li><a href="#"><i class="fa-solid fa-globe"></i> Yum World</a></li>
	</ul>
	</div>
</div> 

<p id="copyright">Yum World © 2023</p>
</footer>
