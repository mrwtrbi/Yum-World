<!DOCTYPE html>
<html>
	<?php
		include_once("head.php");
	?>
	<head>
		<title>YUM WORLD</title>
	</title>

<body>

	<?php
		include_once("header.php");
	?>


<main>
	<?php
		//include_once("mainMenu.php");
		
	?>
		
	<div class="main-text">	
		<div class="main-content">
		<br><br><br><br>
		<img id='logo-accueil' src='../img/Logo.png' width="20%">
		<br><br><br>
		<p>Vous êtes passioné de cuisine ? Vous aimez découvrir le monde à travers votre assiette ? <br><br>
		Notre site vous comblera de bonheur ! Voyagez à travers le monde entier à travers les plats que nous vous proposons.<br><br>
		Sur notre site, vous pourrez acheter des plats mais également avoir accès aux recettes que nous proposons. <br><br>
		Ne perdez pas de temps et parcourez le monde à travers nos plats !</p>
		<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div>

	</div>
</main>

	<?php
		include_once("footer.php");
	?>

</body>

</html>
